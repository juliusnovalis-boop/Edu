import { NextRequest, NextResponse } from "next/server";
import { applyCors, handlePreflight } from "@/lib/server/security/cors";
import { checkRateLimit } from "@/lib/server/security/rate-limit-edge";

/**
 * Proxy global (anciennement « middleware ») — EduSync Pro.
 *
 * Rôle CENTRALISÉ (pentest #2) :
 *   1. préflights CORS propres (OPTIONS → 204) ;
 *   2. limiteur de débit sur TOUTES les routes `/api` (règle ECC/SEC-07) —
 *      les 32 handlers sont couverts ici, sans exception ni oubli possible ;
 *   3. politique CORS restreinte : `Access-Control-Allow-Origin` n'est posé
 *      QUE pour une origine autorisée (jamais `*` sur les routes API), en
 *      reflétant l'origine exacte ; `Allow-Credentials: true` avec l'allowlist.
 *
 * En-têtes de sécurité HTTP : posés par `vercel.json` (edge Vercel, source
 * unique — SANS doublon ici pour éviter les valeurs concaténées invalides).
 *
 * NB — Authentification : les routes `/api` vérifient leur session EN BASE
 * (verifySession / requirePermission) dans chaque handler ; le proxy n'effectue
 * pas de requête DB lourde (modèle correct pour le serverless).
 */

export function proxy(request: NextRequest) {
  // 1) Préflight CORS (OPTIONS) — réponse 204 avec les bons en-têtes si autorisé.
  const preflight = handlePreflight(request);
  if (preflight) return preflight;

  const pathname = new URL(request.url).pathname;

  // 2) Limitation de débit — fenêtre glissante en mémoire, fail-open.
  const verdict = checkRateLimit(request, pathname);
  if (verdict.blocked) {
    return NextResponse.json(
      { error: "Trop de requêtes. Réessayez dans quelques secondes." },
      { status: 429, headers: verdict.headers },
    );
  }

  // 3) Réponse normale → en-têtes CORS restreints (si origine autorisée).
  const response = NextResponse.next();
  applyCors(request, response);
  for (const [key, value] of Object.entries(verdict.headers)) {
    response.headers.set(key, value);
  }
  return response;
}

export const config = {
  /**
   * Matcher : tout sauf les assets statiques internes et les fichiers publics
   * servis tels quels. Contrairement au défaut Next (qui exclut `api`), on
   * INCLUT `/api` pour y appliquer la politique CORS et le rate limiting.
   */
  matcher: ["/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml).*)"],
};
