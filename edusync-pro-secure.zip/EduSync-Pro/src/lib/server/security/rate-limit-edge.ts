/**
 * Limiteur de débit léger exécuté dans le proxy global (règle ECC/SEC-07
 * « Rate limiting on all endpoints »).
 *
 * Pourquoi ici : les 32 routes `/api/*` sont couvertes par UN SEUL point
 * d'application, sans oubli possible lors de l'ajout d'une route. Aucune
 * requête base de données n'est émise — le proxy s'exécute sur chaque
 * requête et doit rester cheap (modèle serverless, cf. `src/proxy.ts`).
 *
 * Couche 1 (ce fichier) : fenêtre glissante en mémoire, par IP et par route,
 * résistante au flood. Couche 2 : `LoginRateLimiter` (PostgreSQL, persistance
 * et verrouillage de compte) à conserver dans le handler de connexion.
 *
 * Limite connue assumée : en multi-instances, chaque instance a son propre
 * compteur. La remediation documentée est un compteur partagé (Redis) avant
 * tout scale-out horizontal.
 *
 * Fail-open délibéré : une erreur interne ne doit JAMAIS bloquer l'application.
 */

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();
const MAX_KEYS = 20_000;

export type RateLimitVerdict = {
  blocked: boolean;
  limit: number;
  remaining: number;
  retryAfterSeconds: number;
};

type Rule = { limit: number; windowMs: number };

/** Règles nommées — une par famille de routes sensible. */
const RULES = {
  login: { limit: 10, windowMs: 5 * 60_000 },
  register: { limit: 5, windowMs: 60 * 60_000 },
  seed: { limit: 5, windowMs: 60_000 },
  ai: { limit: 30, windowMs: 60_000 },
  mutate: { limit: 60, windowMs: 60_000 },
  read: { limit: 300, windowMs: 60_000 },
} satisfies Record<string, Rule>;

/** Routes explicitement exemptées (sondes de supervision). */
const EXEMPT = new Set(["/api/health", "/api/ai/health", "/api/core/status"]);

function pickRule(method: string, pathname: string): Rule | null {
  if (!pathname.startsWith("/api/")) return null;
  if (EXEMPT.has(pathname)) return null;
  if (pathname === "/api/auth/login") return RULES.login;
  if (pathname === "/api/auth/register") return RULES.register;
  if (pathname.startsWith("/api/seed")) return RULES.seed;
  if (pathname.startsWith("/api/ai")) return RULES.ai;
  if (method === "GET" || method === "HEAD") return RULES.read;
  return RULES.mutate;
}

export function clientIp(request: Request): string {
  const fwd = request.headers.get("x-forwarded-for");
  if (fwd) {
    const first = fwd.split(",")[0]?.trim();
    if (first && first.length <= 45) return first;
  }
  const real = request.headers.get("x-real-ip");
  if (real && real.length <= 45) return real;
  return "unknown";
}

function prune(now: number): void {
  if (buckets.size <= MAX_KEYS) return;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
    if (buckets.size <= MAX_KEYS) break;
  }
}

export function checkRateLimit(
  request: Request,
  pathname: string,
): RateLimitVerdict & { headers: Record<string, string> } {
  const failOpen: RateLimitVerdict & { headers: Record<string, string> } = {
    blocked: false,
    limit: 0,
    remaining: 0,
    retryAfterSeconds: 0,
    headers: {},
  };

  try {
    const rule = pickRule(request.method, pathname);
    if (!rule) return failOpen;

    const now = Date.now();
    const key = `${pathname}:${clientIp(request)}`;
    let bucket = buckets.get(key);

    if (!bucket || bucket.resetAt <= now) {
      prune(now);
      bucket = { count: 0, resetAt: now + rule.windowMs };
      buckets.set(key, bucket);
    }

    bucket.count += 1;
    const remaining = Math.max(0, rule.limit - bucket.count);
    const retryAfterSeconds = Math.max(0, Math.ceil((bucket.resetAt - now) / 1000));
    const blocked = bucket.count > rule.limit;

    return {
      blocked,
      limit: rule.limit,
      remaining,
      retryAfterSeconds,
      headers: {
        "X-RateLimit-Limit": String(rule.limit),
        "X-RateLimit-Remaining": String(remaining),
        "X-RateLimit-Reset": String(Math.ceil(bucket.resetAt / 1000)),
        ...(blocked ? { "Retry-After": String(retryAfterSeconds || 1) } : {}),
      },
    };
  } catch {
    return failOpen;
  }
}
