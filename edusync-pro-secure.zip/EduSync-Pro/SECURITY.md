# Revue de sécurité — alignement sur les règles ECC

Audit d'EduSync-Pro confronté aux règles de `rules/common/security.md` du
projet open source [affaan-m/ECC](https://github.com/affaan-m/ECC) (MIT),
puis correction des écarts et mise en ordre du dépôt.

## Statut par règle

| Règle ECC | État | Preuve dans le code |
|---|---|---|
| No hardcoded secrets | ✅ conforme | aucun `sk-…` / `AIza…` / clé Supabase en source ; `.env` ignoré, `.env.example` sans valeur |
| Validate required secrets at startup | ✅ conforme | `src/lib/server/environment.ts` + `security-config.ts` |
| All user inputs validated | ✅ conforme | validation dans chaque handler, `assertTable` sur `/api/data/[table]` |
| SQL injection prevention | ✅ conforme | Drizzle ORM 100 % paramétré, aucune interpolation de variable dans le SQL |
| XSS prevention | ⚠️ partiel | aucun `dangerouslySetInnerHTML` ; CSP actuelle `script-src 'self' 'unsafe-inline'` (voir « Écarts restants ») |
| CSRF protection enabled | ✅ conforme | cookie `httpOnly + secure + sameSite=lax` (`auth.ts`) — les mutations cross-site ne reçoivent pas le cookie |
| Authentication / authorization verified | ✅ conforme | sessions HMAC signées, révocation en base, relecture du rôle EN BASE, `requirePermission` sur chaque route sensible (`/api/seed`, `/api/auth/admin-password`) |
| Rate limiting on all endpoints | ✅ **corrigé** | `src/lib/server/security/rate-limit-edge.ts` appliqué dans `src/proxy.ts` sur les 32 routes `/api` |
| Error messages don't leak sensitive data | ✅ conforme | aucun `err.stack` / `err.message` renvoyé au client |
| Audit trail | ✅ conforme | `logAudit` + `AUDIT_ACTIONS` sur les actions sensibles |
| Weak hashing (MD5/SHA-1) | ✅ conforme | scrypt + sel aléatoire (`security/password.ts`), rétrocompatibilité SHA-256 dépréciée (F-17) |

## Correctifs apportés par cette branche

### 1. Rate limiting branché (ECC/SEC-07)
Le module `LoginRateLimiter` (PostgreSQL) existait mais **n'était appelé par
aucune des 32 routes**. Ajout de `rate-limit-edge.ts`, exécuté dans le proxy :

| Route | Limite |
|---|---|
| `POST /api/auth/login` | 10 / 5 min / IP |
| `POST /api/auth/register` | 5 / h / IP |
| `POST /api/seed*` | 5 / min / IP |
| `/api/ai/*` | 30 / min / IP |
| autres mutations `/api` | 60 / min / IP |
| lectures `/api` | 300 / min / IP |
| `/api/health`, `/api/ai/health`, `/api/core/status` | exemptées (supervision) |

Réponse `429` avec `Retry-After` + `X-RateLimit-*`. **Fail-open** : une erreur
interne du compteur ne bloque jamais l'application.
Couche 1 = mémoire (rapide, sans DB) ; couche 2 = `LoginRateLimiter` (PostgreSQL)
à conserver côté handler pour le verrouillage de compte.

### 2. Dépôt remis en ordre
Purge de 364 fichiers d'artefacts qui ne doivent jamais être versionnés :

- `out/` et `.next-mobile/` — sorties de build Next (~18 Mo)
- `k6-results.json` (12,8 Mo), logs `dev.*`, `k6-*`, `metro.*`, `typecheck-verify.*`
- `package-lock.json.agent-backup`, fichier parasite `1.1.0`
- `.expo/`, `.vercel/`

`684 → 320 fichiers trackés`. Le `.gitignore` a été renforcé pour que ces
chemins ne puissent plus revenir.

## Écarts restants (connus, non bloquants)

1. **CSP `script-src 'self' 'unsafe-inline'`** — poseuse dans `vercel.json`.
   Un `unsafe-inline` affaiblit la protection XSS. La remediation est un
   **nonce par requête** généré dans `src/proxy.ts` (comme Next.js le documente)
   et le retrait de `vercel.json` pour cette en-tête ; cela exige une validation
   en navigateur sur toutes les pages avant mise en production.
2. **Rate limit en mémoire** — en multi-instances chaque instance a son propre
   compteur. Remediation : compteur partagé (Redis) avant scale-out.
3. **`npm audit`** — dépendances à faire passer en CI bloquant sur
   `high`/`critical` (déjà couvert partiellement par Dependabot).

## Vérifications exécutées

```bash
npm run typecheck   # 0 erreur
npm run test:security
```
